package com.example.proyectofinal.modelos

data class Restaurante(
    var plato: Int,
    var nombre: String,
    var descripcion: String,
    var foto: Int
)