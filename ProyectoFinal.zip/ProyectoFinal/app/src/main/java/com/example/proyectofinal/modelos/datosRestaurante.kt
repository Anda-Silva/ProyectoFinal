package com.example.proyectofinal.modelos

import com.example.proyectofinal.R


var restaurante = listOf(
    Restaurante(plato = 1, nombre = "" + "Frijolada", descripcion = "" + "Esta abundante comida usualmente contiene arroz blanco, frijoles rojos, carne molida o picada, plátano, chorizo, maíz, chicharrón de cerdo, huevo frito, arepa y un aguacate.", foto = R.drawable.frijolada),
    Restaurante(plato = 2, nombre = "" + "Lechona", descripcion = "" + "La lechona es una mezcla de garbanzos, carne de cerdo, especias y ocasionalmente arroz (dependiendo de la zona) que se sirve a menudo con una arepa.)", foto = R.drawable.lechona),
    Restaurante(plato = 3, nombre = "" + "Ajiaco", descripcion = "" + "Este plato es una sopa blanca hecha con pollo, una variedad de dos o tres tipos de papas, maíz, crema agria, y generalmente se sirve con arroz blanco y aguacate.", foto = R.drawable.ajiaco),
    Restaurante(plato = 4, nombre = "" + "Sancocho", descripcion = "" + "Siempre contiene yuca, maíz, papas y plátano, y por lo general se sirve junto con arroz blanco. ", foto = R.drawable.sancocho),
    Restaurante(plato = 5, nombre = "" + "Changua", descripcion = "" + " La sopa a base de leche se hace con agua, leche, huevo, cebollas y cilantro y a menudo se sirve con pan y chocolate caliente", foto = R.drawable.changua),
    Restaurante(plato = 6, nombre = "" + "Fritanga", descripcion = "" + "Este plato abundante y lleno de carne contiene una variedad de carnes a la parrilla (pollo, carne de res, chicharrón de cerdo, chorizo) y generalmente se sirve con una variedad de diferentes tipos de papas, arepas, plátanos y maíz.", foto = R.drawable.fritanga),
    Restaurante(plato = 7, nombre = "" + "Tamales", descripcion = "" + "Los colombianos tradicionalmente comen tamales con carne, vegetales, frutas o queso y este manjar a base de maíz es servido y cocinado envuelto en una hoja de plátano.", foto = R.drawable.tamal),
    Restaurante(plato = 8, nombre = "" + "Pandebono", descripcion = "" + "Elaborado con harina de maíz, almidón de yuca, queso y huevo, y ocasionalmente se sirve con pasta de guayaba. ", foto = R.drawable.pandebono),
    Restaurante(plato = 9, nombre = "" + "Cuchuco", descripcion = "" + " Esta sopa contiene maíz, cebada, puré de frijoles, guisantes, zanahorias, papas, cilantro y ajo.", foto = R.drawable.cuchu),
    Restaurante(plato = 10, nombre = "" + "Caldo de costilla", descripcion = "" + "Es una sopa a base de agua que contiene papas, cilantro y costillas de res o un corte diferente de res.", foto = R.drawable.caldo)








)
