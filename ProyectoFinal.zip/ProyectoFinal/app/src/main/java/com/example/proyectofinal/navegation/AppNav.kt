package com.example.proyectofinal.navegation

sealed class AppNav(val route: String) {
    object Principal : AppNav(route = "firstScreen")
    object Secundaria : AppNav(route = "secondScreen")
    object Tercera : AppNav(route = "thirdScreen")
}