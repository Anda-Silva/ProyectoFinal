package com.example.proyectofinal.navegation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.proyectofinal.screens.Principal
import com.example.proyectofinal.screens.SecondScreen
import com.example.proyectofinal.screens.Tercera

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.Principal.route,
    ){
        composable(route = AppNav.Principal.route){Principal(navController)}
        composable(route = AppNav.Secundaria.route){SecondScreen(navController)}
        composable(route = AppNav.Tercera.route){Tercera(navController)}

    }
}