package com.example.proyectofinal.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.proyectofinal.R
import com.example.proyectofinal.navegation.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Principal(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar() {
                Column(modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally) {

                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "",
                        modifier = Modifier.clickable {
                            navController.navigate(route = AppNav.Principal.route)
                        })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "RESTAURANTE EL TUFO")
                    Spacer(modifier = Modifier.width(20.dp))
                }
            }
        }
    ) {
        BodyContent(navController)
    }
}


@Composable
fun BodyContent(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painter = painterResource(R.drawable.jijiji), contentDescription = "")
        Spacer(modifier = Modifier.height(50.dp))
        Button(onClick = { navController.navigate(route = AppNav.Secundaria.route) }) {
            Text(text = "NEXT")
        }
    }
}














