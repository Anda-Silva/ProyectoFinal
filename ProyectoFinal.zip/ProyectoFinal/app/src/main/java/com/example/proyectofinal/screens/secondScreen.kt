package com.example.proyectofinal.screens

import android.annotation.SuppressLint
import android.content.res.Configuration
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.proyectofinal.modelos.Restaurante
import com.example.proyectofinal.modelos.restaurante
import com.example.proyectofinal.navegation.AppNav
import com.example.proyectofinal.navegation.AppNavigation

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun SecondScreen(navController: NavController){
    Scaffold(
        topBar = {
            TopAppBar {
                Column(modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally) {

                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "",
                        modifier = Modifier.clickable {
                            navController.navigate(route = AppNav.Tercera.route)
                        })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "CUENTA")
                    Spacer(modifier = Modifier.width(20.dp))
                }
            }
        }
    ) {
        Conversacion(restaurante)

    }

}

@Composable
fun SecondBodyContent (plato:Int, nombre:String, descripcion: String, foto: Int ) {
    Row(modifier = Modifier.padding(8.dp)) {
        Image(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .border(1.5.dp, MaterialTheme.colors.onPrimary),
            contentDescription = "",
            painter = painterResource(foto)
        )

        Spacer(modifier = Modifier.width(8.dp))
        var isExpanded by remember { mutableStateOf(false) }
        val colordeFondo by animateColorAsState(
            if (isExpanded) MaterialTheme.colors.secondaryVariant else MaterialTheme.colors.surface
        )
        Column(modifier = Modifier.clickable { isExpanded = !isExpanded }) {
            Text(text = "Plato: " + plato.toString(), fontSize = 30.sp)

            Spacer(modifier = Modifier.width(4.dp))

            Surface(
                shape = MaterialTheme.shapes.medium,
                elevation = 1.dp,
                color = colordeFondo,
                modifier = Modifier
                    .animateContentSize()
                    .padding(1.dp)
            ) {
                Text(
                    text = "Nombre: " +nombre + "                                                          " + descripcion,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    maxLines = if (isExpanded) Int.MAX_VALUE else 1
                )
            }
        }
    }
}

@Composable
fun Conversacion(datos : List<Restaurante>) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column() {
            LazyColumn() {
                items(datos) { messages ->
                    SecondBodyContent(messages.plato, messages.nombre, messages.descripcion, messages.foto)
                }
            }//fin items
        }//fin lazycolumn
    }//fin conversacion
}
