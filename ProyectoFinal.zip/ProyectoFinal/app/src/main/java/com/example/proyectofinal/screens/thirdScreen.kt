package com.example.proyectofinal.screens

import android.annotation.SuppressLint
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.proyectofinal.R
import com.example.proyectofinal.navegation.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Tercera (navController: NavController) {
    Scaffold (
        topBar = {
            TopAppBar() {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "",
                    modifier = Modifier.clickable {
                        navController.navigate(route = AppNav.Principal.route)
                    })
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "PRINCIPAL")
                Spacer(modifier = Modifier.width(20.dp))

                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "",
                    modifier = Modifier.clickable {
                        navController.navigate(route = AppNav.Secundaria.route)
                    })
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "MENU")
                Spacer(modifier = Modifier.width(20.dp))
            }
        }
    ) {
        ThirdBodyContent(navController)
    }
}

@Composable
fun ThirdBodyContent (navController: NavController) {
    Row(modifier = Modifier.padding(8.dp)) {
        Image(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .border(1.5.dp, MaterialTheme.colors.onPrimary),
            contentDescription = "",
            painter = painterResource(R.drawable.cuchu)
        )

        Spacer(modifier = Modifier.width(8.dp))
        var isExpanded by remember { mutableStateOf(false) }
        val colordeFondo by animateColorAsState(
            if (isExpanded) MaterialTheme.colors.secondaryVariant else MaterialTheme.colors.surface
        )
        Column(modifier = Modifier.clickable { isExpanded = !isExpanded }) {
            Text(text = "Plato: 9" , fontSize = 30.sp)

            Spacer(modifier = Modifier.width(4.dp))

            Surface(
                shape = MaterialTheme.shapes.medium,
                elevation = 1.dp,
                color = colordeFondo,
                modifier = Modifier
                    .animateContentSize()
                    .padding(1.dp)
            ) {
                Text(
                    text = "Nombre: Cuchuco descripcion: Esta sopa contiene maíz, cebada, puré de frijoles, guisantes, zanahorias, papas, cilantro y ajo.",
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    maxLines = if (isExpanded) Int.MAX_VALUE else 1
                )
            }
        }
    }
}
